import React from 'react';
import LoginForm from '../components/LoginForm.jsx';

function LoginPage() {
    return <LoginForm />;
}

export default LoginPage;