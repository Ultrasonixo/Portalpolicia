import React from 'react';
import BoletimForm from '../components/BoletimForm';

function BoletimPage() {
  return (
    <BoletimForm />
  );
}

export default BoletimPage;