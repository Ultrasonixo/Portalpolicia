import React from 'react';
import RegisterForm from '../components/RegisterForm.jsx';

function RegisterPage() {
    return <RegisterForm />;
}

export default RegisterPage;