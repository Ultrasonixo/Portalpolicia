// pages/portal-juridico.jsx
import React from 'react';
import PortalJuridico from '../components/PortalJuridico.jsx';

export default function PortalJuridicoPage() {
  return (
    <div>
      <PortalJuridico />
    </div>
  );
}
