import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';

// Importando o Contexto e a Proteção
import { AuthProvider } from './context/AuthContext.jsx';
import ProtectedRoute from './components/ProtectedRoute.jsx';

// Importando os Layouts
import MainLayout from './components/MainLayout.jsx';
import PoliceLayout from './components/PoliceLayout.jsx'; // O layout do dashboard que criamos

// Importando TODAS as Páginas
import HomePage from './pages/HomePage.jsx';
import BoletimPage from './pages/BoletimPage.jsx';
import RegisterPage from './pages/RegisterPage.jsx';     // Civil
import LoginPage from './pages/LoginPage.jsx';           // Civil
import LoginPolicial from './pages/LoginPolicial.jsx';     // Policial
import RegisterPolicial from './pages/RegisterPolicial.jsx'; // Policial (corrigindo o nome do import)
import ConcursosPage from './pages/ConcursosPage.jsx';
import JuridicoPage from './pages/Portaljuridico.jsx';
import PoliceDashboard from './pages/PoliceDashboard.jsx'; // A nova página do dashboard

import './App.css';

function App() {
  return (
    <AuthProvider>
      <Routes>
        {/* =================================================================== */}
        {/* GRUPO 1: PÁGINAS DE AUTENTICAÇÃO POLICIAL (TELA CHEIA)            */}
        {/* Estas rotas ficam FORA de qualquer layout para não terem Header.   */}
        {/* =================================================================== */}
        <Route path="/policia/login" element={<LoginPolicial />} />
        <Route path="/policia/register" element={<RegisterPolicial />} />


        {/* =================================================================== */}
        {/* GRUPO 2: PÁGINAS PÚBLICAS E CIVIS (SEMPRE COM HEADER E FOOTER)    */}
        {/* Mantivemos a sua estrutura com o MainLayout aqui.                  */}
        {/* =================================================================== */}
        <Route element={<MainLayout />}>
          <Route path="/" element={<HomePage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/juridico" element={<JuridicoPage />} /> 
          <Route path="/concursos" element={<ConcursosPage />} />
          
          {/* CORREÇÃO DO BOLETIM DE OCORRÊNCIA: */}
          {/* Adicionamos a instrução 'requiredType' para dizer quem pode acessar. */}
          <Route 
            path="/boletim" 
            element={
              <ProtectedRoute>
                <BoletimPage />
              </ProtectedRoute>
            } 
          />
        </Route>


        {/* =================================================================== */}
        {/* GRUPO 3: DASHBOARD POLICIAL (PROTEGIDO E COM LAYOUT PRÓPRIO)      */}
        {/* Esta seção é nova e usa seu próprio layout e proteção.            */}
        {/* =================================================================== */}
        <Route 
          path="/policia" 
          element={
            <ProtectedRoute requiredType="policial">
              <PoliceLayout />
            </ProtectedRoute>
          }
        >
          <Route index element={<Navigate to="dashboard" />} />
          <Route path="dashboard" element={<PoliceDashboard />} />
          {/* Adicione outras rotas do dashboard aqui, ex: /policia/admin */}
        </Route>

      </Routes>
    </AuthProvider>
  );
}

export default App;